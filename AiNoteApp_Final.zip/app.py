
import pytesseract
from PIL import Image, ImageDraw, ImageFont
import streamlit as st
import os
import tempfile
import random
import string
from fpdf import FPDF

# Set the Tesseract path if needed
# pytesseract.pytesseract.tesseract_cmd = r'/usr/bin/tesseract'  # Linux/macOS
# For Windows: uncomment and set path
# pytesseract.pytesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# --- OCR Function ---
def extract_text_from_image(image_file):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_file.read())
        tmp_path = tmp.name
    image = Image.open(tmp_path)
    text = pytesseract.image_to_string(image)
    return text

# --- Render Text on Notebook Paper with Handwriting Variability ---
def render_text_to_notebook(text, font_path, paper_bg_path, pen_color="black", highlight=False):
    bg = Image.open(paper_bg_path).convert("RGB")
    draw = ImageDraw.Draw(bg)
    font_size = 24
    x, y = 50, 50
    line_spacing = 40
    max_width = bg.width - 60

    base_font = ImageFont.truetype(font_path, font_size)
    def get_random_font():
        return ImageFont.truetype(font_path, font_size + random.choice([-1, 0, 1]))

    for line in text.split('\n'):
        words = line.split()
        line_buffer = ""
        for word in words:
            test_line = f"{line_buffer} {word}".strip()
            w, _ = draw.textsize(test_line, font=base_font)
            if w > max_width:
                if highlight:
                    draw.rectangle([x - 5, y - 2, x + draw.textlength(line_buffer, font=get_random_font()) + 5, y + line_spacing - 10], fill="#fff89a")
                draw.text((x, y), line_buffer, font=get_random_font(), fill=pen_color)
                y += line_spacing
                line_buffer = word
            else:
                line_buffer = test_line
        if line_buffer:
            if highlight:
                draw.rectangle([x - 5, y - 2, x + draw.textlength(line_buffer, font=get_random_font()) + 5, y + line_spacing - 10], fill="#fff89a")
            draw.text((x, y), line_buffer, font=get_random_font(), fill=pen_color)
            y += line_spacing

    output_path = os.path.join(tempfile.gettempdir(), "notebook_output.jpg")
    bg.save(output_path)
    return output_path

# --- Generate PDF ---
def convert_image_to_pdf(image_path):
    pdf = FPDF()
    pdf.add_page()
    pdf.image(image_path, x=10, y=10, w=190)
    pdf_path = os.path.join(tempfile.gettempdir(), "notebook_output.pdf")
    pdf.output(pdf_path)
    return pdf_path

# --- Streamlit App ---
st.set_page_config(page_title="AI Note Generator", layout="centered")
st.title("📝 AI Note Generator - Notebook Style")

uploaded_file = st.file_uploader("Upload image or screenshot of notes", type=["png", "jpg", "jpeg"])
font_options = ["handwriting1.ttf", "handwriting2.ttf", "Upload your own font"]
font_choice = st.selectbox("Choose a handwriting font:", font_options)

custom_font = None
if font_choice == "Upload your own font":
    uploaded_font = st.file_uploader("Upload your handwriting font (.ttf)", type="ttf")
    if uploaded_font:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".ttf") as tmp_font:
            tmp_font.write(uploaded_font.read())
            custom_font = tmp_font.name

pen_color = st.color_picker("Choose pen color", value="#000000")
highlight_toggle = st.checkbox("Highlight text")

st.markdown("---")

# Placeholder for future handwriting training interface
with st.expander("✍️ Train Your Handwriting into a Font"):
    st.write("Upload scans of your handwritten letters (A–Z). This feature will let you train a unique handwriting font.")
    uploaded_letter_images = st.file_uploader("Upload scanned letters (A–Z)", type=["png", "jpg"], accept_multiple_files=True)
    if uploaded_letter_images:
        st.info("This feature is in development. For now, you can upload a handwriting .ttf font file.")

if uploaded_file:
    text = extract_text_from_image(uploaded_file)
    st.subheader("Extracted Text")
    st.text_area("Text from image:", text, height=200)

    font_path = custom_font if custom_font else f"fonts/{font_choice}"
    notebook_paper_path = "assets/notebook_paper.jpg"

    if st.button("Generate Notebook Page"):
        output_image_path = render_text_to_notebook(text, font_path, notebook_paper_path, pen_color, highlight_toggle)
        st.image(output_image_path, caption="Generated Note", use_column_width=True)

        with open(output_image_path, "rb") as img_file:
            st.download_button("Download Note as Image", img_file, file_name="note.jpg")

        pdf_path = convert_image_to_pdf(output_image_path)
        with open(pdf_path, "rb") as pdf_file:
            st.download_button("Download Note as PDF", pdf_file, file_name="note.pdf")
